import pyspark
import os
import json
import argparse

from dotenv import load_dotenv
from pathlib import Path
from pyspark.sql.types import StructType
from pyspark.sql.functions import to_timestamp,col,when

dotenv_path = Path('/resources/.env')
load_dotenv(dotenv_path=dotenv_path)
postgres_host = os.getenv('POSTGRES_CONTAINER_NAME')
postgres_db = os.getenv('POSTGRES_DB')
postgres_user = os.getenv('POSTGRES_USER')
postgres_password = os.getenv('POSTGRES_PASSWORD')
sparkcontext = pyspark.SparkContext.getOrCreate(conf=(
        pyspark
        .SparkConf()
        .setAppName('Dibimbing')
        .setMaster('local')
        .set("spark.jars", "/opt/postgresql-42.2.18.jar")
    ))
sparkcontext.setLogLevel("WARN")

spark = pyspark.sql.SparkSession(sparkcontext.getOrCreate())
spark
from pyspark.sql.functions import col, udf, pandas_udf
from pyspark.sql.types import IntegerType
# Define the UDF logic
def string_length(s):
    return len(s)
import pandas as pd
spark.conf.set("spark.sql.join.preferSortMergeJoin", "true")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.join.preferSortMergeJoin", "false")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "1000000000")
jdbc_url = f'jdbc:postgresql://{postgres_host}/{postgres_db}'
jdbc_properties = {
    'user': postgres_user,
    'password': postgres_password,
    'driver': 'org.postgresql.Driver',
    'stringtype': 'unspecified'
}

retail_df = spark.read.jdbc(
    jdbc_url,
    'public.retail',
    properties=jdbc_properties
)
print(retail_df)
retail_df.show(20)
from pyspark.sql.functions import sum

# total_sales_df = retail_df.groupBy("InvoiceNo").agg(sum("Quantity").alias("TotalSales"))

# # Show the first few rows of the analytics DataFrame
# total_sales_df.show()

# Calculate the total retail sales
retail_df = retail_df.withColumn("TotalSales", col("Quantity") * col("UnitPrice"))

# Group the data by the "Country" column and calculate the total retail sales
sales_by_country = retail_df.groupBy("Country").agg(sum("TotalSales").alias("TotalSales"))

# Show the result
sales_by_country.show()
# Save the result to a CSV file
output_csv_path = "sales_by_country.csv"
sales_by_country.write.csv(output_csv_path, header=True)

# Stop the Spark session
# spark.stop()
import pyspark
import os

import time
from dotenv import load_dotenv
from pathlib import Path

from pyspark.sql.functions import col,rank, row_number 
from pyspark.sql.window import Window
dotenv_path = Path('/resources/.env')
load_dotenv(dotenv_path=dotenv_path)
postgres_host = os.getenv('POSTGRES_CONTAINER_NAME')
postgres_db = os.getenv('POSTGRES_DB')
postgres_user = os.getenv('POSTGRES_USER')
postgres_password = os.getenv('POSTGRES_PASSWORD')
sparkcontext = pyspark.SparkContext.getOrCreate(conf=(
        pyspark
        .SparkConf()
        .setAppName('Dibimbing')
        .setMaster('local')
        .set("spark.jars", "/spark-scripts/postgresql-42.2.18.jar")
    ))
sparkcontext.setLogLevel("WARN")

# create spark pyspark
spark = pyspark.sql.SparkSession(sparkcontext.getOrCreate())
spark

# idk, i just follow python script in notebook
spark.conf.set("spark.sql.join.preferSortMergeJoin", "true")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.join.preferSortMergeJoin", "false")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "1000000000")
jdbc_url = f'jdbc:postgresql://{postgres_host}/{postgres_db}'
jdbc_properties = {
    'user': postgres_user,
    'password': postgres_password,
    'driver': 'org.postgresql.Driver',
    'stringtype': 'unspecified'
}
# connect postgre via jdbc
retail_df = spark.read.jdbc(
    jdbc_url,
    'public.retail',
    properties=jdbc_properties
)


# Calculate the total sales for each product
retail_df = retail_df.withColumn("TotalSales", col("Quantity") * col("UnitPrice"))

# Define a window specification for ranking
window_spec = Window.orderBy(col("TotalSales").desc())

# Rank products by total sales
retail_df = retail_df.withColumn("Rank", rank().over(window_spec))
retail_df = retail_df.select("Rank", "Description", "TotalSales")

# Define the number of rows per partition (e.g., 100 rows per partition)
rows_per_partition = 1000

# Calculate the partition column based on row_number and rows_per_partition
retail_df = retail_df.withColumn(
    "Partition",
    (row_number().over(Window.orderBy("Rank")) - 1) / rows_per_partition
)

# Make the Partition column an integer
retail_df = retail_df.withColumn("Partition", col("Partition").cast("integer"))

# show df
retail_df.show()

now = int(time.time())

# make unique file based on unix timestamp
output_csv_path = "/spark-scripts/Rank_Product_by_Total_Sales_" + str(now) + ".csv"

# Write the DataFrame to a CSV file with partitioning
retail_df.write.partitionBy("Partition").csv(output_csv_path, header=True)
